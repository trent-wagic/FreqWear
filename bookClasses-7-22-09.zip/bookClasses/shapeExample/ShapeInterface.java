/** Interface for handling shapes */
public interface ShapeInterface
{
	public void setShape(String shapeType);
	public void clearShapes();
}